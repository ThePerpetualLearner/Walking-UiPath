# yearlyreport-performer
Generate Yearly Report Performer process

Processes all the transactions loaded by the Dispatcher to the queue. TransactionItem type needs to be QueueItem

Requires: UIPath Community Edition or UIPath licensed tool
